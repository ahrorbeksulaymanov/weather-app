export const API_KEY = "cdad9c68c6a1849b581aac98e3794f61"
export const API_PATH = "https://api.openweathermap.org/data/2.5/forecast"