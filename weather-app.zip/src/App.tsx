import MainPage from './components/mainPage';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'antd/dist/antd.css';
const App = () => {

  return (
    <div className="App">
      <MainPage />
    </div>
  );
}

export default App;
